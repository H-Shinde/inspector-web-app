"""Update an existing PythonAnywhere installation."""
from datetime import datetime
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys

SETTINGS_START = '# BEGIN BISON RELEASE SETTINGS'
SETTINGS_END = '# END BISON RELEASE SETTINGS'
SETTINGS = """
_session = "django.contrib.sessions.middleware.SessionMiddleware"
_csrf = "django.middleware.csrf.CsrfViewMiddleware"
MIDDLEWARE = [
    {
        _session: "accounts.app_sessions.AppSessionMiddleware",
        _csrf: "accounts.app_sessions.AppCsrfMiddleware",
    }.get(entry, entry)
    for entry in MIDDLEWARE
]
_auth = MIDDLEWARE.index("django.contrib.auth.middleware.AuthenticationMiddleware")
_access = "accounts.access.AdminAppAccessMiddleware"
_actor = "accounts.request_actor.RequestActorMiddleware"
if _access not in MIDDLEWARE:
    MIDDLEWARE.insert(_auth + 1, _access)
if _actor not in MIDDLEWARE:
    MIDDLEWARE.insert(_auth + 1, _actor)
INSPECTOR_SESSION_COOKIE_NAME = globals().get("INSPECTOR_SESSION_COOKIE_NAME", "inspector_sessionid")
INSPECTOR_CSRF_COOKIE_NAME = globals().get("INSPECTOR_CSRF_COOKIE_NAME", "inspector_csrftoken")
TEMPLATES[0]["DIRS"] = [__FRONTEND__, *(directory for directory in TEMPLATES[0]["DIRS"] if str(directory) != __FRONTEND__)]
STATIC_ROOT = globals().get("STATIC_ROOT") or BASE_DIR / "staticfiles"
_host = next((host for host in ALLOWED_HOSTS if host.endswith(".pythonanywhere.com") and not host.startswith(".")), "")
if _host and globals().get("FRONTEND_URL", "http://localhost").startswith(("http://localhost", "http://127.0.0.1")):
    FRONTEND_URL = f"https://{_host}"
if _host and globals().get("INSPECTOR_FRONTEND_URL", "http://localhost").startswith(("http://localhost", "http://127.0.0.1")):
    INSPECTOR_FRONTEND_URL = f"https://{_host}/inspector"
"""

ROUTES = """
from django.urls import re_path
from django.views.generic import TemplateView

urlpatterns += [
    re_path(r"^inspector(?:/.*)?$", TemplateView.as_view(template_name="inspector/index.html")),
    re_path(r"^(?!api(?:/|$)|admin(?:/|$)).*$", TemplateView.as_view(template_name="index.html")),
]
"""


def main():
    source = Path(__file__).resolve().parent
    home = Path.home()
    backend = home / 'backend'
    frontend = home / 'frontend' / 'dist'
    settings_file = backend / 'config' / 'settings.py'
    if not settings_file.is_file():
        raise SystemExit('Expected your existing backend at ~/backend. No files changed.')

    database = backend / 'db.sqlite3'
    if database.is_file():
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
        backup = home / f'admin-db-backup-{stamp}.sqlite3'
        with sqlite3.connect(database) as current, sqlite3.connect(backup) as destination:
            current.backup(destination)
        print(f'Database backup: {backup}', flush=True)

    shutil.copytree(source / 'admin' / 'backend', backend, dirs_exist_ok=True)
    shutil.copytree(source / 'admin' / 'dist', frontend, dirs_exist_ok=True)
    inspector_dist = source / 'inspector' / 'dist'
    shutil.copytree(inspector_dist, frontend / 'inspector', dirs_exist_ok=True)
    shutil.copytree(inspector_dist / 'assets', frontend / 'assets', dirs_exist_ok=True)
    for name in ('favicon.svg', 'icons.svg'):
        shutil.copy2(inspector_dist / name, frontend / name)

    existing = settings_file.read_text()
    before, marker, managed = existing.partition(SETTINGS_START)
    if marker:
        _, end, after = managed.partition(SETTINGS_END)
        if not end:
            raise SystemExit('The existing Bison release settings block is incomplete.')
        existing = before + after
    settings_file.write_text(existing.rstrip() + '\n\n' + SETTINGS_START
                             + SETTINGS.replace('__FRONTEND__', repr(str(frontend)))
                             + SETTINGS_END + '\n')

    urls = backend / 'config' / 'urls.py'
    urls.write_text(urls.read_text() + ROUTES)
    for command in (('check',), ('migrate', '--noinput'), ('collectstatic', '--noinput')):
        subprocess.run([sys.executable, 'manage.py', *command], cwd=backend, check=True)
    print('Both apps updated. Click Reload in the PythonAnywhere Web tab.')


if __name__ == '__main__':
    main()
