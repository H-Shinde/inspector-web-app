Bison Valuation PythonAnywhere update
November 18, 2026

This update is for an existing deployment at ~/backend and ~/frontend/dist.
It includes the current Django backend and both production frontend builds.

1. Upload pythonanywhere-update-2026-11-18-r2.zip to your PythonAnywhere home directory.
2. Open a Bash console and activate the virtualenv shown in the Web tab.
3. Run:
   cd ~
   unzip -o pythonanywhere-update-2026-11-18-r2.zip
   python inspector-update/install.py
4. In the Web tab, verify these static mappings:
   /assets/      /home/YOUR_USERNAME/frontend/dist/assets
   /agreements/  /home/YOUR_USERNAME/frontend/dist/agreements
5. Click Reload. The admin opens at / and the inspector app at /inspector/.

The installer backs up ~/backend/db.sqlite3 before migrating it. The package
contains no local database, private settings, email credentials, or media.
