Update an existing PythonAnywhere installation at ~/backend and ~/frontend/dist.

1. Upload pythonanywhere-update.zip to your PythonAnywhere home directory.
2. In a Bash console, activate the SAME virtualenv configured in the Web tab.
3. Run:
   cd ~
   unzip -o pythonanywhere-update.zip
   python inspector-update/install.py
4. Click Reload in the Web tab.

The installer backs up the hosted SQLite database before applying migrations.
It preserves existing settings.py, email_config.json, uploaded media and users.
It installs the updated backend, both frontends, and the inspector URL route.
Existing /assets/ static mapping must point to ~/frontend/dist/assets.
Admin: https://YOUR_USERNAME.pythonanywhere.com/
Inspector: https://YOUR_USERNAME.pythonanywhere.com/inspector/

This archive excludes local databases, email credentials, local settings and virtualenvs.
