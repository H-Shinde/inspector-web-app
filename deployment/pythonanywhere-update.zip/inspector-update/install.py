"""Update an existing PythonAnywhere installation."""
from pathlib import Path
import subprocess
import sys

home = Path.home()
if not (home / 'backend/config/settings.py').exists():
    raise SystemExit('Expected your existing backend at ~/backend. No files changed.')
source = Path(__file__).resolve().parent
for script in ['admin/deploy_admin.py', 'inspector/deploy_inspector.py']:
    subprocess.run([sys.executable, str(source / script)], check=True)
print('Both apps updated. Reload your app in the PythonAnywhere Web tab.')
